<?php
	session_start();
include 'dbs.php';


	$msg = "";
	// kapag napindot yung upload na buton :3
	if (isset($_POST['upload']))
	{
		$target = "images/".basename($_FILES['image']);
		$db = mysqli_connect("localhost", "root", "", "comments");

		// Kukuha ng mga inupload mong data sa form :3
		
		$content = $_POST['text'];

		$sql = "INSERT INTO login (image) VALUES ('$image', '$content')";
		mysqli_query($db, $sql); //naglalagay ng mga inupload mong data sa database mo :3

		//uploading image...
		if ($_FILES['image'], $target)
		{
			$msg = "Aba uki nakapag upload kana bes";
		}
		else
		{
			$msg = "Hala ka ayaw. ano susuko ka nalang ba?";
		}
	}
	

?>
