<?php
	session_start();
include 'dbs.php';
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">
  <!--  <script type="text/javascript" src="jquery.js"></script>-->
   <!-- <script type="text/javascript" src="sct.js"></script>-->
  <!-- <link rel="stylesheet" href="Styles/home.css">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <link rel="stylesheet" href="kopilibrary/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="kopilibrary/bootstrap.min_2.css">-->
 <!-- <link rel="stylesheet" href="kopilibrary/anima.css">-->
  <!--<script src="kopilibrary/ajax.js"></script>
  <script src="kopilibrary/ajax_2.js"></script>
  <script src="kopilibrary/ajax2.js"></script>
  <script src="kopilibrary/ajax2_2.js"></script>
  -->
   <title>Chikkatweet</title>

</head>
<body>

<!--<nav class="navbar navbar-default navbar-fixed-top">-->
  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="500" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>

	<div class="row-body">
		<div class="col-md-2 left">
		<br>
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID = $id";
					$result = $conn->query($sql);
			
					$row = $result->fetch_assoc();
					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";
					
					echo  $row['Fname']. " " ; 
					echo  $row['Lname']. "<br>" ;
					echo  $row['Age']. "<br>" ;
					echo  $row['Gender']. "<br>" ;
					echo  $row['Uname']. "<br>" ;

				}
				else
				{
					echo "not logged in";
				}
			?>
			<form method="POST" action="upload2.php" enctype="multipart/form-data">
				<input type="hidden" name="size" value="1000000" >
				<br>
				<input type="file" class = "sub" name="image" class="input-lg " >
				<input type="submit" name="upload" value="Upload Image" class="sub" >
			</form>
								<?php
								if(isset($_SESSION['id']))
								{
									$id = $_SESSION['id'];
									// kapag napindot yung upload na buton :3
									if (isset($_POST['upload']))
									{
										$target = "images/".basename($_FILES['image']['name']);
										// Kukuha ng mga inupload mong data sa form
										$image = $_FILES['image']['name'];

										$sql = "UPDATE login SET dp='$image' WHERE ID = '$id'";
										$result = $conn->query($sql); //naglalagay ng mga inupload mong data sa database mo

										//uploading image...
										if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) 
										{
											$msg = "Aba uki nakapag upload kana bes";
										}
										else
										{
											$msg = "Hala ka ayaw. ano susuko ka nalang ba?";
										}
									}

									}
									else
									{
										echo "not logged in";
									}
						?>
			
		</div>

		<div class="col-md-7 center">
			<div class="posts">	
			<form action="editinfo.php" method="POST">
				<h3 class="sign-up">Edit Profile</h3>
				First Name: <br>
				<input type="text" class="fname l" name="Fname" placeholder="First Name"/>
				<br><br>Last Name:<br>
				<input type="text" class="lname l" name="lname" placeholder="Last Name"/>
				<br><br>Age:<br>
				<input type="text" class="age l" name="age"placeholder="Age"/>
				<br><br>
				<button class="sub" type="Submit">Save</button>	
				<br><br>
			</form>
			<form action="editpass.php" method="POST">
				<h3>Change Password </h3>
				Old Password:<br>
				<input type="Password" class="user l" name="OPass" placeholder="Old Password"/>
				<br><br>Password:<br>
				<input type="Password" class="pass l" name="Pass" placeholder="Password"/>
				<br><br>Retype Password:<br>
				<input type="Password" class="Rpass l" name="RPass" placeholder="Retype Password"/>
				<br><br>
				<button class="sub" type="Submit">Save</button>	
			</form>
			</div>
		</div>
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="sea" name="search" placeholder="Search"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
			<h3>Friends</h3>
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM friendlist WHERE user_id = $id";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						$friendid = $row['friend_id'];
						$sql = "SELECT * FROM login WHERE ID = $friendid";
						$result = $conn->query($sql);
						$row = $result->fetch_assoc();			
						echo  "• ".$row['Fullname']. "<br>" ;
					}
				}
				else
				{
				
				}
			?>
		</div>
	</div>
	
</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
