<?php
	session_start();
include 'dbs.php';
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">
  <!--  <script type="text/javascript" src="jquery.js"></script>-->
   <!-- <script type="text/javascript" src="sct.js"></script>-->
  <!-- <link rel="stylesheet" href="Styles/home.css">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <link rel="stylesheet" href="kopilibrary/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="kopilibrary/bootstrap.min_2.css">-->
 <!-- <link rel="stylesheet" href="kopilibrary/anima.css">-->
  <!--<script src="kopilibrary/ajax.js"></script>
  <script src="kopilibrary/ajax_2.js"></script>
  <script src="kopilibrary/ajax2.js"></script>
  <script src="kopilibrary/ajax2_2.js"></script>
  -->
   <title>Chikkatweet</title>

</head>
<body>
 
           

  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="435" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>

	</div>
	<div class="row-body">
		<div class="col-md-2  left" >
			
			<br>
			<?php
				
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID = $id";
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();

					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";			
					echo  $row['Fullname']. "<br>" ;
					echo  $row['Uname']. "<br>" ;

				}
				else
				{
					echo "not logged in";
				}
			?>
		</div>
<div class="col-md-7 center">

			<div class="post" >
				<form action="post.php" method="POST">
					<input type="text" class="posttext" name="Post" placeholder="Write Post Here"/>
					<br><br>
					<button class="p" type="Submit">Post</button>					
				</form>
			</div>
			<div class="posts">	
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];

					$sql = "SELECT * FROM login WHERE ID ='$id'";
					$result = $conn->query($sql);
					$username = $row['Fullname'];
					$sql = "SELECT * FROM posts ORDER BY ID DESC";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						
						$post = $row['ID'];
						echo "<form action='postsss.php' method='POST'>";
							echo "<button class='postss' type='Submit'>";
							echo "<input type='hidden' name='id' value = ".$row['ID'].">";
							echo $row['Name']. "<br>" ; 
							echo $row['time']. "<br><br>" ;
							echo  $row['Posttext']."<br><br>";
							echo  "Likes: ".$row['likes'];
							echo "</button>";
						echo "</form>";						
					}
				}
				else
				{
				
				}
			?>
			</div>
		</div>
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="ser" name="search" placeholder="Search"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
			
		</div>
	</div>
</body>



</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
