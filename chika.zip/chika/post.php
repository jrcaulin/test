<?php
session_start();
include 'dbs.php';
	if(isset($_SESSION['id']))
		{
			$id = $_SESSION['id'];
			$sql = "SELECT * FROM login WHERE ID = $id";
			$result = $conn->query($sql);
			
			$row = $result->fetch_assoc();
			$id = $row['ID']. " " ; 
			$name = $row['Fullname'];

			$post = $_POST['Post'];
			$sql = "INSERT INTO posts (user_id,Name,Posttext) 
			VALUES ('$id','$name','$post')";
			$result = $conn->query($sql);
			header("location: home.php");

	echo $post;
		}
		else
		{
			echo "not logged in";
		}

	

