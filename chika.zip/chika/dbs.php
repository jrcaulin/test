<?php
$conn = mysqli_connect("localhost","root","","chikatweet");

if (!$conn){
	die("connection failed:".mysli_connect_error());
}