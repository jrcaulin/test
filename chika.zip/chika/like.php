<?php
	session_start();
include 'dbs.php';
$userid = $_POST['user_id'];
$post_id = $_POST['postid'];
$sql = "INSERT INTO likes (user_id,post_id) 
VALUES ('$userid','$post_id')";
$result = $conn->query($sql);

$sql = "SELECT * FROM posts WHERE ID = '$post_id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();		
$add = $row['likes'] + "1" ;

$sql = "UPDATE posts SET likes='$add' WHERE ID = '$post_id'";
$result = $conn->query($sql);
?>	


<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">
  <!--  <script type="text/javascript" src="jquery.js"></script>-->
   <!-- <script type="text/javascript" src="sct.js"></script>-->
  <!-- <link rel="stylesheet" href="Styles/home.css">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <link rel="stylesheet" href="kopilibrary/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="kopilibrary/bootstrap.min_2.css">-->
 <!-- <link rel="stylesheet" href="kopilibrary/anima.css">-->
  <!--<script src="kopilibrary/ajax.js"></script>
  <script src="kopilibrary/ajax_2.js"></script>
  <script src="kopilibrary/ajax2.js"></script>
  <script src="kopilibrary/ajax2_2.js"></script>
  -->
   <title>Chikkatweet</title>

</head>
<body>

<!--<nav class="navbar navbar-default navbar-fixed-top">-->
  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="500" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>
	<div class="row-body">
		<div class="col-md-2 left">
			
			<br>
			<?php
				
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID = $id";
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();

					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";			
					echo  $row['Fullname']. "<br>" ;
					echo  $row['Uname']. "<br>" ;

				}
				else
				{
					echo "not logged in";
				}
			?>
		</div>

		<div class="col-md-7 center">
		<div class="postss">
				<?php
					$post_id = $_POST['id'];
					$post = $_POST['id'];
					$ids = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID ='$ids' "; 
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();		
					$username = $row['Fullname'];


					$sql = "SELECT * FROM posts WHERE ID = '$post_id'";
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();		
					echo $row['Name']. "<br>" ; 
					echo $row['time']. "<br><br>" ;
					echo  $row['Posttext']."<br><br>";
					$sql = "SELECT * FROM likes WHERE user_id = '$id' AND post_id = '$post'";
							$result = $conn->query($sql);
							if(!$row = $result->fetch_assoc())
							{
								echo "<form action='like.php' method='POST'>
									<input type='hidden' name='postid' value = ".$post.">
									<input type='hidden' name='id' value = ".$post.">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
									<button class='sub' type='Submit'>Like</button>
								</form>";
							}
							else
							{
								echo "<form action='unike.php' method='POST'>
									<input type='hidden' name='postid' value = ".$post.">
									<input type='hidden' name='id' value = ".$post.">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
									<button class='sub' type='Submit'>Unlike</button>
								</form>";	
							}

					echo "<br>";
					echo "<form action='comment.php' method='POST'>
						<input type='hidden' name='postid' value = ".$post.">
						<input type='hidden' name='id' value = ".$post.">
						<input type='hidden' name='username' value = ".$username.">
						<input type='hidden' name='userid' value = ".$_SESSION['id'].">			
						<input type='text' class='posttext' name='comment' placeholder='Write Comment Here'/>
						<button class='sub' type='Submit'>Comment</button>					
					</form>";
					echo "<br><br><div class='coms'>";
					echo "<h3>Comments</h3>";
					$post_id = $_POST['id'];
					$sql = "SELECT * FROM coment WHERE post_id = '$post_id' ORDER BY ID DESC";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						$userid = $row['user_id'];
						echo "<br>".$userid = $row['username']."<br>";
						echo $date = $row['time']."<br><br>";
						echo $com = $row['comment']."<br>";
									
					}
					echo "</div>";
				?>	
				</div>		
		</div>
				
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="ser" name="search" placeholder="Search"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
			
		</div>
	</div>
</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
