<?php
	session_start();
include 'dbs.php';
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">

   <title>Chikkatweet</title>

</head>
<body>

<!--<nav class="navbar navbar-default navbar-fixed-top">-->
  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="500" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>

	<div class="row-body">
		<div class="col-md-2 left">
			
			<br>
			<?php
				
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID = $id";
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();

					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";			
					echo  $row['Fullname']. "<br>" ;
					echo  $row['Uname']. "<br>" ;

				}
				else
				{
					echo "not logged in";
				}
			?>
		</div>

		<div class="col-md-7 center">
			<div class="col-md-3 leftcenter">
			<h3>Friends</h3>
			<?php
			if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM friendlist WHERE user_id = '$id'";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='username' value =".$row['username'].">
								<input type='hidden' name='friendid' value =".$row['friend_id'].">
								<input type='hidden' name='friendname' value =".$row['friendname'].">	
								<button class='sub3' type='Submit'>• ".$row['friendname']. "</button>
							</form>";
					}
					$sql = "SELECT * FROM friendlist WHERE friend_id = '$id'";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='username' value =".$row['friendname'].">
								<input type='hidden' name='friendid' value =".$row['user_id'].">
								<input type='hidden' name='friendname' value =".$row['username'].">	
								<button class='sub3' type='Submit'>• ".$row['username']. "</button>
							</form>";
					}
						
				}
				else
				{
				
				}
			?>
			</div>
			<div class="col-md-9 rightcenter">
				<div class="pm">
				<?php

					$id = $_SESSION['id'];
					$friendid = $_POST['friendid'];
					$sql = "SELECT * FROM chat WHERE (from_id='$id' AND to_id='$friendid' )OR (to_id='$id' AND from_id='$friendid')";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 	

						echo $row['fromname'].":<br> ".$row['date']."<br>".$row['message']."<br>"."<br>";
					} 
				?>
				</div>
				
				<?php
				
					if (!$_POST['friendid']) {
					echo "wala";
					}
					else
					{
					$friendid = $_POST['friendid'];
					$friendname = $_POST['friendname'];
					$username = $_POST['username'];
					$userid = $_SESSION['id'];
					echo "<div class='f'>
					<form action='send.php' method='POST'>
						<input type='hidden' name='friend_id' value =".$_POST['friendid'].">
						<input type='hidden' name='username' value =".$_POST['username'].">
						<input type='hidden' name='friendname' value =".$_POST['friendname'].">
						<input type='hidden' name='user_id' value =".$_SESSION['id'].">
						<input type='text' class='posttext' name='msg' placeholder='Write Message Here'/>
						<button class='sub' type='Submit'>Send</button>					
					</form>
					</div>";
						
				}
				
				?>
				
			</div>

		</div>
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="ser" name="search" placeholder="Search"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
			
		</div>
	</div>
	<style>
	.pm
{	background-color: #540802;
	padding: 10px;	
	color: #ffffff;
}
.f
{
	background-color: #250000;
	height: 50px;	
	padding: 10px;	
}
	.sub3
	{
		color: #ffffff;
		border-style: none;
		background-color: transparent;
	}
.leftcenter
{
	background-color: #380501;
	color: #ffffff;
}
.rightcenter
{
	background-color: #250000;
	padding: 10px;
		
}
.bg1
{
	position: absolute;
	left: 250px;
}
.Post
{
	color: #000000;
}
.sub1
{
	position: absolute;
	left: 460px;
	top: 15px;
	background-color: transparent;
	color: #ffffff;
}
.comtext
{
	height: 25px;
	width: 595px;
	color: #000000;
}
	.postss
	{
		padding: 20px;
		margin-top: 10px;
		margin-bottom: 10px;
		background-color: #250000;
	}
	.lo
	{
		position: absolute;
	}
	.bg
	{

		font-family: tahoma;
		background-color: #540802;
	}
	
	.tile
	{
		color: #ffffff; 
		font-size: 50px;
		font-family: tahoma;
	}
	.img
	{
		height: 20px;
		width: 20px;
	}
	.login
	{
		padding-top: 15px;
		
	}
	.sub
	{
		color: #ffffff;
		background-color: transparent;
	}
	.row-body
	{
		margin-top: 50px;
		width: 100%:;
		height: 500px;	
	}
	.left
	{
		color: #ffffff;
		left: 20px;
		margin-right: 40px;
		height: 300px;
		background-color: #380501;
		padding: 20px;
	}
	.center
	{

	}
	.right
	{
		color: #ffffff;
		left: 20px;
		padding: 20px; 
		height: 500px;
		background-color: #380501;
	}
	.post
	{
		padding: 20px;
		background-color: #380501;
	}
	.posttext
	{
		
		height: 30px;
		width: 460px;
	}
	.p
	{
		position: absolute;
		color: #ffffff;
		top: 78px;
		width: 75px;
		background-color: transparent;
		left: 600px;
	}
	.ser
	{
		color: #000000;
	}
	.sear
	{
		background-color: transparent;
	}
	.dp
	{
		height: 150px;
		width: 150px;
	}
	.posts
	{
		color: #ffffff;
		padding-left: 20px;
		padding-top: 10px;
		padding-right: 20px;
		padding-bottom: 20px;
		margin-top: 20px;
	}
	.com
	{
		width: 710px;
	}
	.comment
	{
		color: #ffffff;
		top: 78px;
		width: 75px;
		margin-left: 565px;
		background-color: transparent;
	}
	.comm
	{
		padding: 10px;
		margin-top: 10px;
		background-color: #380501; 
	}
	</style>
</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
