<?php
session_start();
include 'dbs.php';

$Uname = $_POST['Uname'];
$Pass = $_POST['Pass'];

$sql = "SELECT * FROM login WHERE Uname = '$Uname' AND Password = '$Pass'" ; 
$result = $conn->query($sql);

if(!$row = $result->fetch_assoc())
{
	header("location: index.php");
	echo "Your username/Password is incorrect!";
}
else {
	header("location: home.php");
	$_SESSION['id'] = $row['ID'];


	
	$des = "logged In";
	$Uname['Uname'] = $row['Uname'];
	$sql = "INSERT INTO logs (des, Uname) 
	VALUES ('$des','$Uname')";
	$result = $conn->query($sql);
}
