<h3>Friends</h3>
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM friendlist WHERE user_id = '$id' OR friend_id = '$id'";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						if ($id = $row['friend_id']) 
						{
							$friendid = $row['user_id'];
							$sql = "SELECT * FROM login WHERE ID = $friendid";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();
							echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='friendies' value =".$row['ID'].">	
								<button class='sub3' type='Submit'>• ".$row['Fullname']. "</button>				
							</form>
							<br>";
						//<input type='hidden' name='friendies' value =".$row['friend_id'].">
						}
						elseif ($id = $row['user_id']) 
						{
							$friendid = $row['friend_id'];
							$sql = "SELECT * FROM login WHERE ID = $friendid";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();
							echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='friendies' value =".$row['ID'].">	
								<button class='sub3' type='Submit'>• ".$row['Fullname']. "</button>				
							</form>
							<br>";
						}
						else
						{

						}
							
					}
						
				}
				else
				{
				
				}
			?>





			if ($id = $row['friend_id']) 
						{
							$friendid = $row['user_id'];
							$sql = "SELECT * FROM login WHERE ID = $friendid";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();
							echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='friendies' value =".$row['ID'].">	
								<button class='sub3' type='Submit'>• ".$row['Fullname']. "</button>				
							</form>
							<br>";
						//<input type='hidden' name='friendies' value =".$row['friend_id'].">
						}
						elseif ($id = $row['user_id']) 
						{
							$friendid = $row['friend_id'];
							$sql = "SELECT * FROM login WHERE ID = $friendid";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();
							echo "<form action='chat.php' method='POST'>
								<input type='hidden' name='friendies' value =".$row['ID'].">	
								<button class='sub3' type='Submit'>• ".$row['Fullname']. "</button>				
							</form>
							<br>";
						}
						else
						{

						}


						echo"<div class='f'>
					<form action='post.php' method='POST'>
						<input type='text' class='posttext' name='Post' placeholder='Enter Friend Name Here'/>
						<input type='text' class='posttext' name='Post' placeholder='Write Message Here'/>
						<button class='sub' type='Submit'>Send</button>					
					</form>

				</div>";




$sql = "SELECT * FROM likes WHERE user_id = '$id' AND post_id = '$post'";
							$result = $conn->query($sql);
							if(!$row = $result->fetch_assoc())
							{
								echo "<form action='like.php' method='POST'>
									<input type='hidden' name='post_id' value = ".$post.">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
									<button class='sub' type='Submit'>Like</button>
								</form>";
							}
							else
							{
								echo "<form action='like.php' method='POST'>
									<input type='hidden' name='post_id' value = ".$post.">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
									<button class='sub' type='Submit'>Unlike</button>
								</form>";	
							}
							
