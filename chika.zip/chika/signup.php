<?php

include 'dbs.php';
$Pass = $_POST['Pass'];
$RPass = $_POST['RPass'];

If($Pass = $RPass)
{

	$Fname = $_POST['Fname'];
	$Lname = $_POST['Lname'];
	$Age = $_POST['Age'];
	$Gender = $_POST['Gender'];
	$Uname = $_POST['Uname']."@chikatweet.com";
	$Pass = $_POST['Pass'];
	$Fullname = $_POST['Fname']." ".$_POST['Lname'];
	$image = "facebook-default-no-profile-pic.jpg";


	echo $Fname."<br>";
	echo $Lname."<br>";
	echo $Age."<br>";
	echo $Gender."<br>";
	echo $Uname."<br>";
	echo $Pass."<br>";
	echo $Fullname."<br>";


	$sql = "INSERT INTO login (Fname,Lname,Age,Gender,Uname,Password,Fullname,dp) 
	VALUES ('$Fname','$Lname','$Age','$Gender','$Uname','$Pass','$Fullname','$image')";
	$result = $conn->query($sql);
	header("location: index.php");
}
else
{
	echo "invalid";
}

