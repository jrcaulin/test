<?php
	session_start();
include 'dbs.php';
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">
  <!--  <script type="text/javascript" src="jquery.js"></script>-->
   <!-- <script type="text/javascript" src="sct.js"></script>-->
  <!-- <link rel="stylesheet" href="Styles/home.css">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <link rel="stylesheet" href="kopilibrary/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="kopilibrary/bootstrap.min_2.css">-->
 <!-- <link rel="stylesheet" href="kopilibrary/anima.css">-->
  <!--<script src="kopilibrary/ajax.js"></script>
  <script src="kopilibrary/ajax_2.js"></script>
  <script src="kopilibrary/ajax2.js"></script>
  <script src="kopilibrary/ajax2_2.js"></script>
  -->
   <title>Chikkatweet</title>

</head>
<body>

<!--<nav class="navbar navbar-default navbar-fixed-top">-->
  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="500" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>
<div class="row-body">
		<div class="col-md-2 left">
			
			<br>
			<?php
				
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM login WHERE ID = $id";
					$result = $conn->query($sql);
					$row = $result->fetch_assoc();

					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";			
					echo  $row['Fullname']. "<br>" ;
					echo  $row['Uname']. "<br>" ;

				}
				else
				{
					echo "not logged in";
				}
			?>
		</div>

		<div class="col-md-7 center">
			<div class="posts">	
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM friendship ORDER BY ID DESC";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						
						echo "<div class = 'postss'>";
							$from = $row['from_id'];
							$sql = "SELECT * FROM login WHERE ID = $from";
							$result = $conn->query($sql);
							$row = $result->fetch_assoc();

							echo "<div class='dp'>";
							echo "<img src='images/".$row['dp']."' class='dp' >";
							echo "</div>"."<br>";			
							echo  $row['Fullname']. "<br>" ;
							echo  $row['Uname']. "<br><br>" ;
							
							echo "<form action='confirm.php' method='POST'>
									<input type='hidden' name='friend_id' value = ".$from.">
									<button class='sub' type='Submit'>Confirm</button>
								</form>";
						echo "</div>";
					}
				}
				else
				{
				
				}
			?>
			</div>
		</div>
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="ser" name="search" placeholder="Search"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
			<h3>Friends</h3>
			<?php
				if(isset($_SESSION['id']))
				{
					$id = $_SESSION['id'];
					$sql = "SELECT * FROM friendlist WHERE user_id = $id";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{ 
						$friendid = $row['friend_id'];
						$sql = "SELECT * FROM login WHERE ID = $friendid";
						$result = $conn->query($sql);
						$row = $result->fetch_assoc();			
						echo  "• ".$row['Fullname']. "<br>" ;
					}
				}
				else
				{
				
				}
			?>
		</div>
	</div>
	
</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
