<?php
include 'dbs.php';
include 'search.php';

$userid = $_POST['id'];
$sql = "INSERT INTO friend (user_id,friend_id,friend_name) VALUES ('$id','$fid','$fn')";
	$result = $conn->query($sql);

