<?php
session_start();
include 'dbs.php';
if(isset($_SESSION['id']))
		{
			$id = $_SESSION['id'];
			$friendid = $_POST['friend_id'];
			$sql = "DELETE FROM friendship WHERE (from_id='$friendid'AND to_id ='$id') OR (from_id='$id'AND to_id ='$friendid')";
			$result = $conn->query($sql);
			
			$sql = "SELECT * FROM login WHERE ID ='$id'";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();

			$username= $row['Fullname'];

			$sql = "SELECT * FROM login WHERE ID = $friendid";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();

			$friendname = $row['Fullname'];

			$sql = "INSERT INTO friendlist (user_id,username,friend_id,friendname) VALUES ('$id','$username','$friendid','$friendname')";
			$result = $conn->query($sql);
			header("location: notif.php");
		}
		else
		{
			echo "not logged in";
		}
