-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2017 at 02:05 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `codesmail`
--

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `ID` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `fromname` text NOT NULL,
  `to_id` int(11) NOT NULL,
  `toname` text NOT NULL,
  `message` varchar(1000) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`ID`, `from_id`, `fromname`, `to_id`, `toname`, `message`, `date`) VALUES
(60, 4, 'Kenneth', 6, 'Kenji', 'hi', '2017-05-26 04:52:01'),
(61, 4, 'Kenneth', 6, 'Kenji', 'hello', '2017-05-26 04:52:41'),
(62, 4, 'Kenneth', 6, 'Kenji', 'hi', '2017-05-26 04:54:26'),
(63, 4, 'Kenneth', 6, 'Kenji', 'hi', '2017-05-26 04:55:08'),
(64, 4, 'Kenneth', 6, 'Kenji', 'hi', '2017-05-26 04:59:01'),
(65, 5, 'ken', 4, 'Kenneth', 'hi', '2017-05-26 05:00:01'),
(66, 4, 'Kenneth', 5, 'ken', 'hello', '2017-05-26 05:00:21'),
(67, 5, 'ken', 4, 'Kenneth', 'hi', '2017-05-26 05:04:54'),
(68, 4, 'Kenneth', 5, 'ken', 'qwerty', '2017-05-26 05:05:35'),
(69, 5, 'ken', 4, 'Kenneth', 'hehehehehe', '2017-05-26 05:10:03'),
(70, 5, 'ken', 4, 'Kenneth', 'kwe', '2017-05-26 05:11:38'),
(71, 0, 'ken', 0, 'Kenneth', '', '2017-05-26 05:12:54'),
(72, 4, 'Kenneth', 5, 'ken', 'hoy palkups', '2017-05-26 12:25:55'),
(73, 5, 'ken', 4, 'Kenneth', 'hoy baket?', '2017-05-26 12:26:16'),
(74, 17, 'kenneth', 18, 'Jericho', 'hi', '2017-06-03 07:23:01'),
(75, 18, 'Jericho', 17, 'kenneth', 'hello', '2017-06-03 07:23:18'),
(76, 21, 'kier', 4, 'Kenneth', 'hello', '2017-12-23 01:02:07'),
(77, 4, 'Kenneth', 21, 'kier', 'hi', '2017-12-23 01:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `coment`
--

CREATE TABLE `coment` (
  `ID` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment` mediumtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coment`
--

INSERT INTO `coment` (`ID`, `post_id`, `comment`, `time`, `user_id`, `username`) VALUES
(1, 42, 'hi din', '2017-05-26 18:29:16', 4, 'Kenneth Franco'),
(2, 42, 'yow', '2017-05-26 18:54:43', 4, 'Kenneth'),
(3, 42, 'hoy', '2017-05-26 19:00:23', 4, 'Kenneth'),
(4, 42, 'hoy', '2017-05-26 19:02:19', 4, 'Kenneth'),
(5, 42, 'kkdkdkd', '2017-05-26 19:02:34', 4, 'Kenneth'),
(6, 42, 'hhhjjjj n', '2017-05-26 19:05:13', 4, 'Kenneth'),
(7, 42, 'hhhjjjj n', '2017-05-26 19:06:32', 4, 'Kenneth');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `ID` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `comment` int(11) NOT NULL,
  `name` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE `friendlist` (
  `ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` text NOT NULL,
  `friend_id` int(11) NOT NULL,
  `friendname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `friendlist`
--

INSERT INTO `friendlist` (`ID`, `user_id`, `username`, `friend_id`, `friendname`) VALUES
(23, 4, 'Kenneth Franco', 6, 'Kenji franco'),
(24, 5, 'ken Francis', 4, 'Kenneth Franco'),
(25, 18, 'Jericho Ducusin', 17, 'kenneth franco'),
(26, 4, 'Kenneth Franco', 21, 'kier Franco');

-- --------------------------------------------------------

--
-- Table structure for table `friendship`
--

CREATE TABLE `friendship` (
  `ID` int(11) NOT NULL,
  `from_id` int(11) NOT NULL,
  `to_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`ID`, `user_id`, `post_id`) VALUES
(2, 4, 42),
(3, 21, 42);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `Fname` text NOT NULL,
  `Lname` text NOT NULL,
  `Age` int(4) NOT NULL,
  `Gender` text NOT NULL,
  `Uname` text NOT NULL,
  `Password` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Fullname` text NOT NULL,
  `dp` varchar(10000) NOT NULL,
  `dpname` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Fname`, `Lname`, `Age`, `Gender`, `Uname`, `Password`, `date`, `Fullname`, `dp`, `dpname`) VALUES
(4, 'Kenneth', 'Franco', 18, 'Male', 'ken_franco@codesmail.com', 'duel1998', '2017-05-20 10:21:43', 'Kenneth Franco', 'Agents of S.H.I.E.L.D S04E21 [Filmia].mkv_snapshot_41.43_[2017.05.16_23.55.50].jpg', ''),
(5, 'ken', 'Francis', 16, 'Male', 'ken@codesmail.com', 'duel1998', '2017-05-20 07:53:12', 'ken Francis', '47591.jpg', ''),
(6, 'Kenji', 'franco', 18, 'Male', 'ken12', '1998', '2017-05-20 05:52:09', 'Kenji franco', 'facebook-default-no-profile-pic.jpg', ''),
(7, 'kier', 'Franco', 14, 'Male', 'kier', 'duel123', '2017-05-20 05:52:13', 'kier Franco', 'facebook-default-no-profile-pic.jpg', ''),
(8, 'Mashiyyat', 'Delos Santos', 19, 'Male', 'Mash', 'mashiyyatdialga', '2017-05-20 05:52:21', 'Mashiyyat Delos Santos', 'facebook-default-no-profile-pic.jpg', ''),
(9, 'Banjo', 'Guevarra', 30, 'Male', 'Banjo', 'banjo0025', '2017-05-20 05:53:03', 'Banjo Guevarra', 'facebook-default-no-profile-pic.jpg', ''),
(10, 'Jericho', 'Ducusin', 18, 'Male', 'jerichohebreza@yahoo.com', 'magdalo1256', '2017-05-20 03:00:01', 'Jericho Ducusin', '14922905_1149631725130732_843427022_o.jpg', ''),
(11, '', '', 0, '', '', 'kjljkj', '2017-05-20 05:52:24', ' ', 'facebook-default-no-profile-pic.jpg', ''),
(12, 'jjlkjk', 'lkjllk ', 0, '', 'kjkff6t', 'jbhjgyu', '2017-05-20 05:52:29', 'jjlkjk lkjllk ', 'facebook-default-no-profile-pic.jpg', ''),
(13, 'ken', 'Francis', 18, 'Male', 'kenfr@codesmail.com', 'duel1998', '2017-05-20 05:55:40', 'ken Francis', 'facebook-default-no-profile-pic.jpg', ''),
(14, 'ken', 'Francis', 18, 'Male', 'ken1@codesmail.com', 'duel1998', '2017-05-20 07:53:49', 'ken Francis', 'Haikyuu 2nd Season - 02.mp4_snapshot_01.44_[2017.05.02_10.46.56].jpg', ''),
(15, 'king', 'Francis', 12, 'Male', 'king@codesmail.com', 'duel1998', '2017-05-20 06:02:32', 'king Francis', '47591.jpg', ''),
(16, 'jericho', 'ducusin', 17, 'Male', 'jeric12345@codesmail.com', 'jericho', '2017-05-20 10:27:39', 'jericho ducusin', 'facebook-default-no-profile-pic.jpg', ''),
(17, 'kenneth', 'franco', 18, 'Male', 'kenji@codesmail.com', 'duel1998', '2017-05-20 10:28:05', 'kenneth franco', 'facebook-default-no-profile-pic.jpg', ''),
(18, 'Jericho', 'Ducusin', 19, 'Male', 'jericho@codesmail.com', 'jrchdcsn', '2017-06-03 07:21:21', 'Jericho Ducusin', 'facebook-default-no-profile-pic.jpg', ''),
(19, 'kenji', 'moruzaki', 18, 'Male', 'kenji@codesmail.com', 'duel1998', '2017-06-03 07:21:55', 'kenji moruzaki', 'facebook-default-no-profile-pic.jpg', ''),
(20, 'kenn', 'd', 12, 'Male', 'wd@codesmail.com', 'sd', '2017-11-09 16:12:02', 'kenn d', 'facebook-default-no-profile-pic.jpg', ''),
(21, 'kier', 'Franco', 12, 'Male', 'kier@codesmail.com', 'duel1998', '2017-12-23 00:59:13', 'kier Franco', 'IMG_20170802_164341_1.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `Uname` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `des` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `Uname`, `time`, `des`) VALUES
(1, 'ken_franco@codesmail.com', '2017-05-05 15:57:14', 'logged In'),
(2, 'ken_franco@codesmail.com', '2017-05-05 16:08:36', 'logged Out'),
(3, 'ken_franco@codesmail.com', '2017-05-05 16:08:49', 'logged In'),
(4, 'ken_franco@codesmail.com', '2017-05-05 16:35:53', 'logged Out'),
(5, 'ken_franco@codesmail.com', '2017-05-05 16:36:46', 'logged In'),
(6, 'ken_franco@codesmail.com', '2017-05-05 16:52:32', 'logged In'),
(7, 'ken_franco@codesmail.com', '2017-05-06 01:34:56', 'logged In'),
(8, 'ken_franco@codesmail.com', '2017-05-07 03:19:41', 'logged In'),
(9, 'ken@codesmail.com', '2017-05-07 03:19:51', 'logged In'),
(10, 'ken_franco@codesmail.com', '2017-05-07 03:53:51', 'logged Out'),
(11, 'ken_franco@codesmail.com', '2017-05-07 03:54:30', 'logged In'),
(12, 'ken@codesmail.com', '2017-05-07 03:58:43', 'logged In'),
(13, 'ken@codesmail.com', '2017-05-07 03:59:28', 'logged Out'),
(14, 'ken_franco@codesmail.com', '2017-05-07 04:00:01', 'logged Out'),
(15, 'ken_franco@codesmail.com', '2017-05-07 05:04:14', 'logged In'),
(16, 'ken_franco@codesmail.com', '2017-05-07 05:25:10', 'logged Out'),
(17, 'ken_franco@codesmail.com', '2017-05-07 05:25:18', 'logged In'),
(18, 'ken_franco@codesmail.com', '2017-05-07 05:43:34', 'logged Out'),
(19, 'ken_franco@codesmail.com', '2017-05-07 05:50:37', 'logged In'),
(20, 'ken_franco@codesmail.com', '2017-05-07 05:56:03', 'logged Out'),
(21, 'ken@codesmail.com', '2017-05-07 05:56:21', 'logged In'),
(22, 'ken@codesmail.com', '2017-05-07 05:58:05', 'logged Out'),
(23, 'ken12', '2017-05-07 05:59:30', 'logged In'),
(24, 'ken12', '2017-05-07 06:01:23', 'logged Out'),
(25, 'ken_franco@codesmail.com', '2017-05-07 06:14:06', 'logged In'),
(26, 'ken_franco@codesmail.com', '2017-05-07 06:16:07', 'logged Out'),
(27, 'ken_franco@codesmail.com', '2017-05-12 07:07:20', 'logged In'),
(28, 'ken_franco@codesmail.com', '2017-05-12 07:08:39', 'logged Out'),
(29, 'ken_franco@codesmail.com', '2017-05-12 15:56:32', 'logged In'),
(30, 'ken_franco@codesmail.com', '2017-05-12 16:30:49', 'logged Out'),
(31, 'ken_franco@codesmail.com', '2017-05-12 16:43:54', 'logged In'),
(32, 'ken_franco@codesmail.com', '2017-05-12 16:45:15', 'logged Out'),
(33, 'Mash', '2017-05-12 16:45:46', 'logged In'),
(34, 'Mash', '2017-05-12 17:23:42', 'logged Out'),
(35, 'Mash', '2017-05-12 17:23:47', 'logged In'),
(36, 'Mash', '2017-05-12 17:28:59', 'logged In'),
(37, 'Mash', '2017-05-12 17:35:01', 'logged Out'),
(38, 'Banjo', '2017-05-12 17:35:33', 'logged In'),
(39, 'ken_franco@codesmail.com', '2017-05-17 03:26:32', 'logged In'),
(40, 'ken_franco@codesmail.com', '2017-05-17 03:27:28', 'logged Out'),
(41, 'ken_franco@codesmail.com', '2017-05-17 03:27:42', 'logged In'),
(42, 'ken_franco@codesmail.com', '2017-05-17 03:44:46', 'logged In'),
(43, 'ken_franco@codesmail.com', '2017-05-17 03:51:51', 'logged Out'),
(44, 'ken_franco@codesmail.com', '2017-05-17 03:54:46', 'logged In'),
(45, 'ken_franco@codesmail.com', '2017-05-17 04:38:46', 'logged In'),
(46, 'ken_franco@codesmail.com', '2017-05-19 22:59:47', 'logged In'),
(47, 'ken_franco@codesmail.com', '2017-05-19 23:23:48', 'logged In'),
(48, 'ken_franco@codesmail.com', '2017-05-19 23:27:22', 'logged In'),
(49, 'ken_franco@codesmail.com', '2017-05-19 23:27:42', 'logged Out'),
(50, 'ken_franco@codesmail.com', '2017-05-19 23:27:45', 'logged In'),
(51, 'ken_franco@codesmail.com', '2017-05-19 23:27:47', 'logged Out'),
(52, 'ken_franco@codesmail.com', '2017-05-19 23:28:34', 'logged In'),
(53, 'ken_franco@codesmail.com', '2017-05-20 02:57:42', 'logged In'),
(54, 'ken_franco@codesmail.com', '2017-05-20 02:57:59', 'logged Out'),
(55, 'jerichohebreza@yahoo.com', '2017-05-20 02:59:04', 'logged In'),
(56, 'jerichohebreza@yahoo.com', '2017-05-20 03:06:42', 'logged Out'),
(57, 'ken_franco@codesmail.com', '2017-05-20 05:05:04', 'logged In'),
(58, 'ken_franco@codesmail.com', '2017-05-20 05:21:16', 'logged Out'),
(59, 'ken_franco@codesmail.com', '2017-05-20 05:22:01', 'logged In'),
(60, 'ken_franco@codesmail.com', '2017-05-20 05:53:32', 'logged Out'),
(61, 'ken1@codesmail.com', '2017-05-20 05:55:19', 'logged In'),
(62, 'ken1@codesmail.com', '2017-05-20 06:00:31', 'logged Out'),
(63, 'king@codesmail.com', '2017-05-20 06:01:42', 'logged In'),
(64, 'king@codesmail.com', '2017-05-20 06:03:35', 'logged Out'),
(65, 'ken_franco@codesmail.com', '2017-05-20 06:08:48', 'logged In'),
(66, 'ken_franco@codesmail.com', '2017-05-20 06:34:30', 'logged Out'),
(67, 'ken_franco@codesmail.com', '2017-05-20 06:40:06', 'logged In'),
(68, 'ken_franco@codesmail.com', '2017-05-20 06:44:58', 'logged Out'),
(69, 'ken_franco@codesmail.com', '2017-05-20 07:14:16', 'logged In'),
(70, 'ken_franco@codesmail.com', '2017-05-20 07:40:56', 'logged Out'),
(71, 'ken_franco@codesmail.com', '2017-05-20 07:41:36', 'logged In'),
(72, 'ken_franco@codesmail.com', '2017-05-20 07:45:05', 'logged Out'),
(73, 'king@codesmail.com', '2017-05-20 07:45:18', 'logged In'),
(74, 'king@codesmail.com', '2017-05-20 07:47:22', 'logged Out'),
(75, 'ken_franco@codesmail.com', '2017-05-20 07:48:19', 'logged In'),
(76, 'ken_franco@codesmail.com', '2017-05-20 07:52:33', 'logged Out'),
(77, 'ken@codesmail.com', '2017-05-20 07:52:49', 'logged In'),
(78, 'ken@codesmail.com', '2017-05-20 07:53:17', 'logged Out'),
(79, 'ken1@codesmail.com', '2017-05-20 07:53:24', 'logged In'),
(80, 'ken1@codesmail.com', '2017-05-20 07:54:01', 'logged Out'),
(81, 'ken_franco@codesmail.com', '2017-05-20 07:54:08', 'logged In'),
(82, 'ken_franco@codesmail.com', '2017-05-20 08:02:32', 'logged Out'),
(83, 'ken@codesmail.com', '2017-05-20 08:02:46', 'logged In'),
(84, 'ken@codesmail.com', '2017-05-20 08:04:02', 'logged Out'),
(85, 'ken_franco@codesmail.com', '2017-05-20 08:04:10', 'logged In'),
(86, 'ken_franco@codesmail.com', '2017-05-20 08:16:08', 'logged Out'),
(87, 'ken_franco@codesmail.com', '2017-05-20 08:18:01', 'logged In'),
(88, 'ken_franco@codesmail.com', '2017-05-20 10:21:52', 'logged Out'),
(89, 'ken_franco@codesmail.com', '2017-05-20 10:26:37', 'logged In'),
(90, 'ken_franco@codesmail.com', '2017-05-20 10:26:56', 'logged Out'),
(91, 'kenji@codesmail.com', '2017-05-20 10:29:40', 'logged In'),
(92, 'kenji@codesmail.com', '2017-05-20 10:30:13', 'logged Out'),
(93, 'ken_franco@codesmail.com', '2017-05-24 10:40:30', 'logged In'),
(94, 'ken_franco@codesmail.com', '2017-05-24 11:11:01', 'logged Out'),
(95, 'ken_franco@codesmail.com', '2017-05-24 11:11:08', 'logged In'),
(96, 'ken_franco@codesmail.com', '2017-05-24 11:24:09', 'logged Out'),
(97, 'ken_franco@codesmail.com', '2017-05-24 11:25:15', 'logged In'),
(98, 'ken_franco@codesmail.com', '2017-05-24 13:19:03', 'logged Out'),
(99, 'ken_franco@codesmail.com', '2017-05-24 13:19:48', 'logged In'),
(100, 'ken_franco@codesmail.com', '2017-05-24 13:52:04', 'logged Out'),
(101, 'ken@codesmail.com', '2017-05-24 13:52:17', 'logged In'),
(102, 'ken@codesmail.com', '2017-05-24 13:52:45', 'logged Out'),
(103, 'ken_franco@codesmail.com', '2017-05-24 13:52:54', 'logged In'),
(104, 'ken_franco@codesmail.com', '2017-05-24 14:45:49', 'logged Out'),
(105, 'ken_franco@codesmail.com', '2017-05-24 14:49:32', 'logged In'),
(106, 'ken_franco@codesmail.com', '2017-05-25 08:00:33', 'logged In'),
(107, 'ken@codesmail.com', '2017-05-25 08:02:59', 'logged In'),
(108, 'ken@codesmail.com', '2017-05-25 08:05:02', 'logged Out'),
(109, 'ken12', '2017-05-25 08:05:25', 'logged In'),
(110, 'ken_franco@codesmail.com', '2017-05-25 17:51:33', 'logged In'),
(111, 'ken@codesmail.com', '2017-05-25 17:52:08', 'logged In'),
(112, 'ken@codesmail.com', '2017-05-25 18:12:05', 'logged Out'),
(113, 'ken_franco@codesmail.com', '2017-05-25 18:12:19', 'logged Out'),
(114, 'ken_franco@codesmail.com', '2017-05-25 18:12:28', 'logged In'),
(115, 'ken_franco@codesmail.com', '2017-05-25 20:54:39', 'logged Out'),
(116, 'ken_franco@codesmail.com', '2017-05-25 20:55:43', 'logged In'),
(117, 'ken_franco@codesmail.com', '2017-05-26 03:30:56', 'logged In'),
(118, 'ken@codesmail.com', '2017-05-26 03:43:10', 'logged In'),
(119, 'ken@codesmail.com', '2017-05-26 03:49:47', 'logged Out'),
(120, 'ken12', '2017-05-26 03:49:55', 'logged In'),
(121, 'ken12', '2017-05-26 04:31:40', 'logged Out'),
(122, 'ken@codesmail.com', '2017-05-26 04:59:53', 'logged In'),
(123, 'ken_franco@codesmail.com', '2017-05-26 05:42:31', 'logged In'),
(124, 'ken@codesmail.com', '2017-05-26 06:03:38', 'logged Out'),
(125, 'ken_franco@codesmail.com', '2017-05-26 06:11:24', 'logged Out'),
(126, 'ken_franco@codesmail.com', '2017-05-26 12:24:29', 'logged In'),
(127, 'ken@codesmail.com', '2017-05-26 12:24:43', 'logged In'),
(128, 'ken@codesmail.com', '2017-05-26 12:32:20', 'logged Out'),
(129, 'ken_franco@codesmail.com', '2017-05-26 13:50:34', 'logged Out'),
(130, 'ken_franco@codesmail.com', '2017-05-26 17:05:58', 'logged In'),
(131, 'ken_franco@codesmail.com', '2017-05-27 02:14:20', 'logged In'),
(132, 'ken_franco@codesmail.com', '2017-05-27 02:32:15', 'logged Out'),
(133, 'ken_franco@codesmail.com', '2017-05-27 02:51:26', 'logged In'),
(134, 'ken_franco@codesmail.com', '2017-05-27 03:09:24', 'logged Out'),
(135, 'ken_franco@codesmail.com', '2017-05-27 09:31:22', 'logged In'),
(136, 'ken_franco@codesmail.com', '2017-05-27 09:45:26', 'logged Out'),
(137, 'ken_franco@codesmail.com', '2017-05-27 09:50:19', 'logged In'),
(138, 'ken_franco@codesmail.com', '2017-05-27 10:32:34', 'logged Out'),
(139, 'ken_franco@codesmail.com', '2017-05-28 05:55:51', 'logged In'),
(140, 'ken_franco@codesmail.com', '2017-06-02 11:00:56', 'logged In'),
(141, 'ken_franco@codesmail.com', '2017-06-02 11:01:29', 'logged In'),
(142, 'ken_franco@codesmail.com', '2017-06-03 07:09:10', 'logged In'),
(143, 'ken_franco@codesmail.com', '2017-06-03 07:14:54', 'logged Out'),
(144, 'ken_franco@codesmail.com', '2017-06-03 07:18:38', 'logged In'),
(145, 'ken_franco@codesmail.com', '2017-06-03 07:19:49', 'logged Out'),
(146, 'jericho@codesmail.com', '2017-06-03 07:21:33', 'logged In'),
(147, 'kenji@codesmail.com', '2017-06-03 07:22:08', 'logged In'),
(148, 'kenji@codesmail.com', '2017-06-03 07:24:54', 'logged Out'),
(149, 'jericho@codesmail.com', '2017-06-03 07:24:57', 'logged Out'),
(150, 'ken_franco@codesmail.com', '2017-11-04 06:32:02', 'logged In'),
(151, 'ken_franco@codesmail.com', '2017-11-04 06:54:57', 'logged In'),
(152, 'ken_franco@codesmail.com', '2017-12-22 23:56:57', 'logged In'),
(153, 'ken_franco@codesmail.com', '2017-12-23 00:57:49', 'logged Out'),
(154, 'kier@codesmail.com', '2017-12-23 00:58:55', 'logged In'),
(155, 'ken_franco@codesmail.com', '2017-12-23 01:00:18', 'logged In'),
(156, 'kier@codesmail.com', '2017-12-23 01:02:52', 'logged Out'),
(157, 'ken_franco@codesmail.com', '2017-12-23 01:03:01', 'logged Out');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `ID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Posttext` varchar(10000) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `img` text NOT NULL,
  `likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`ID`, `user_id`, `Name`, `Posttext`, `time`, `img`, `likes`) VALUES
(37, 15, 'king Francis', 'Hello', '2017-05-20 07:46:15', '', 0),
(38, 15, 'king Francis', 'Hello World', '2017-05-20 07:47:01', '', 0),
(40, 4, 'Kenneth Franco', 'yoe', '2017-05-20 07:49:58', '', 0),
(41, 5, 'ken Francis', 'hi', '2017-05-26 05:27:49', '', 0),
(42, 5, 'ken Francis', 'hello', '2017-05-26 05:27:55', '', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `coment`
--
ALTER TABLE `coment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `friendlist`
--
ALTER TABLE `friendlist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `friendship`
--
ALTER TABLE `friendship`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;
--
-- AUTO_INCREMENT for table `coment`
--
ALTER TABLE `coment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `friendlist`
--
ALTER TABLE `friendlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `friendship`
--
ALTER TABLE `friendship`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
