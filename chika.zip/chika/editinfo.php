<?php
session_start();
include 'dbs.php';

	$id = isset($_SESSION['id']);
	$Fname = $_POST['Fname'];
	$Lname = $_POST['lname'];
	$Age = $_POST['age'];
	$Fullname = $_POST['Fname']." ".$_POST['lname'];

	$sql = "UPDATE login SET Fname = '$Fname', Lname = '$Lname', Age = '$Age', Fullname = '$Fullname' WHERE ID = '$id'";
	$result = $conn->query($sql);
	header("location: settings.php");
	$id = $_SESSION['id'];
	
	$sql = "SELECT * FROM posts WHERE user_id = '$id'";
	$result = $conn->query($sql);
	while($row = $result->fetch_assoc())
	{ 				
			$sql = "UPDATE posts SET name = '$Fullname' WHERE user_id = '$id'";
			$result = $conn->query($sql);
	}