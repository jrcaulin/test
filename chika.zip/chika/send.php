<?php
session_start();
include 'dbs.php';
	echo $friend_id = $_POST['friend_id'];
	echo $user_id = $_POST['user_id'];
	echo $message = $_POST['msg'];
	echo $fname = $_POST['friendname'];
	echo $uname = $_POST['username'];

	$sql = "INSERT INTO chat (from_id,fromname,to_id,toname,message) 
	VALUES ('$user_id','$uname','$friend_id','$fname','$message')";
	$result = $conn->query($sql);
	header("location: chat.php");

							