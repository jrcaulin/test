<?php
session_start();
include 'dbs.php';
if(isset($_SESSION['id']))
	{
		$id = $_SESSION['id'];
		$sql = "SELECT * FROM login WHERE ID = $id";
		$result = $conn->query($sql);
		
		If(!$row = $result->fetch_assoc())
		{
		}
		else 
		{
			$_SESSION['id'] = $row['ID'];
			$des = "logged Out";
			$Uname = $row['Uname'];

			$sql = "INSERT INTO logs (des, Uname) 
			VALUES ('$des','$Uname')";
			$result = $conn->query($sql);
			
			session_destroy();
			header("location: index.php");

		}
	}		