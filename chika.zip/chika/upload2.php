<?php
session_start();
include 'dbs.php';
if(isset($_SESSION['id']))
{
	$id = $_SESSION['id'];
// kapag napindot yung upload na buton :3
	if (isset($_POST['upload']))
	{
		$target = "images/".basename($_FILES['image']['name']);
// Kukuha ng mga inupload mong data sa form
		$image = $_FILES['image']['name'];
		$sql = "UPDATE login SET dp='$image' WHERE ID = '$id'";
		$result = $conn->query($sql); //naglalagay ng mga inupload mong data sa database mo

//uploading image...
		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) 
		{
											
			header("location: settings.php");
		}
		else
		{
			$msg = "Hala ka ayaw. ano susuko ka nalang ba?";
		}
	}
}
else
{
	echo "not logged in";
}
header("location:settings.php");
