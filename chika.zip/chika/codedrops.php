<?php
	session_start();
include 'dbs.php';
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8">
 <head>
     <link href="bootstrap.min.css" rel="stylesheet">
    <link href="likha.css" rel="stylesheet">
  <!--  <script type="text/javascript" src="jquery.js"></script>-->
   <!-- <script type="text/javascript" src="sct.js"></script>-->
  <!-- <link rel="stylesheet" href="Styles/home.css">-->
  <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
  <link rel="stylesheet" href="kopilibrary/bootstrap.min.css">
 <!-- <link rel="stylesheet" href="kopilibrary/bootstrap.min_2.css">-->
 <!-- <link rel="stylesheet" href="kopilibrary/anima.css">-->
  <!--<script src="kopilibrary/ajax.js"></script>
  <script src="kopilibrary/ajax_2.js"></script>
  <script src="kopilibrary/ajax2.js"></script>
  <script src="kopilibrary/ajax2_2.js"></script>
  -->
   <title>Chikkatweet</title>

</head>
<body>

<!--<nav class="navbar navbar-default navbar-fixed-top">-->
  <div class="row-head">
		<div class="col-md-12 header">
			<div class="col-md-6 Chikkatweet">
			<img src="image/chikka.png" class="img-circle" height="100" width="500" >
			</div>
			<div class="col-md-6 login">
				<a href="home.php"><button class="sub">Home <img class="img" src="home.png"> </button>	</a>
				<a href="profile.php"><button class="sub">Profile <img class="img" src="home.png">  </button></a>
				<a href="notif.php"><button class="sub">Notificatiions <img class="img" src="home.png">  </button></a>
				<a href="chat.php"><button class="sub">Chat<img class="img" src="home.png">  </button></a>
				<a href="settings.php"><button class="sub">Settings <img class="img" src="settings.png">  </button></a><br>
			 <form action="logout.php">
					<button class="sub1" type="Logout">Logout <img class="img" src="logout.png"></button>
				</form>	
			</div>
			
		</div>
	</div>
	
	
	<div class="row-body">
		<div class="col-md-2 left">
			<br>
			<?php

				$id = $_POST['id'];
				$sql = "SELECT * FROM login WHERE ID = '$id'" ; 
				$result = $conn->query($sql);
				if(!$row = $result->fetch_assoc())
				{
					echo "User Not found";
				}
				else 
				{
					echo "<div class='dp'>";
					echo "<img src='images/".$row['dp']."' class='dp' >";
					echo "</div>"."<br>";
					echo $row['Fullname']."<br>";
					$fn = $row['Fullname'];
					echo $row['Age']."<br>";
					echo $row['Gender']."<br>";
					echo $row['Uname']."<br>";
					
						$friend_id = $_POST['id']."<br>";
						$user_id = $_SESSION['id'];
						echo "<br>";
						$sql = "SELECT * FROM friendlist WHERE (user_id = '$user_id' AND friend_id = '$friend_id') OR (user_id = '$friend_id' AND friend_id = '$user_id')";
						$result = $conn->query($sql);
						if(!$row = $result->fetch_assoc())
						{
							$sql = "SELECT * FROM friendship WHERE from_id = '$user_id' AND to_id = '$friend_id'";
							$result = $conn->query($sql);
							if(!$row = $result->fetch_assoc())
							{
								echo "<form action='addfriend.php' method='POST'>
									<input type='hidden' name='friend_id' value = ".$_POST['id'].">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
									<button class='sub' type='Submit'>Add Friend</button>
								</form>";
							}
							else
							{
								echo "<form action='cancelfriend.php' method='POST'>
									<input type='hidden' name='friend_id' value = ".$_POST['id'].">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">	
									<button class='sub' type='Submit'>Cancel Friend Request</button>
								</form>";
							}
						}
						else 
						{
							echo "<form action='Unfriend.php' method='POST'>
									<input type='hidden' name='friend_id' value = ".$_POST['id'].">
									<input type='hidden' name='user_id' value = ".$_SESSION['id'].">
								<button class='sub' type='Submit'>Unfriend</button>
							</form>";
						}
					
				}
			?>
			<br>
			<br>
		</div>
		<div class="col-md-7 center">
			<div class="posts">	
				<?php

					$di = $_POST['id'];	
					$sql = "SELECT * FROM posts WHERE user_id = $id ORDER BY ID DESC";
					$result = $conn->query($sql);
					while($row = $result->fetch_assoc())
					{
						$post = $row['ID'];
						echo "<br>";
						echo "<div class = 'postss'>";
						echo $row['Name']. "<br>" ; 
						echo $row['time']. "<br><br>" ;
						echo  $row['Posttext']."<br><br>";
						echo "</div>";
								
					}
				?>
			</div>
		</div>
		<div class="col-md-2 right">
			<form action="search.php" method="POST">
				<input type="text" class="Post" name="search" placeholder="Search Person"/>
				<br><br>
			<button class="sub" type="Submit">Search</button>					
			</form>
		</div>
	</div>

</body>
</html>	
		
		
		
		
		
		
		
		
		
		
		
