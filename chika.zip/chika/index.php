<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>ChikkaTweet - Login </title>
<link rel="stylesheet" type="text/css" href="css1/styles.css">
<link rel="stylesheet" type="text/css" href="css1/styles1.css">
<link rel="stylesheet" type="text/css" href="css1/styles2.css">
</head>

<body bgcolor="white">   


	<div class="loginbox">
	<!--<img src="images/chikka tweet logo.png" class="avatar">
	-->
	
     <form action="login.php" method="POST">
	
	
				<input type="text" class="col-md-2 username" name="Uname" placeholder="Username" required/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				<input type="Password" class="col-md-2 password" name="Pass" placeholder="Password" required/>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				<input type="submit" value="  	Login	         " >
			</form>
			</div>
<?php
		if(isset($_SESSION['id']))
		{
			echo $_SESSION['id'];
			header("location: home.php");
		}
		else
		{
		}
?>

	
	<div class="loginboxx">
<!--	<img src="images/chikka tweet logo.png" class="avatar">
-->
	<form action="signup.php" method="POST">
			<h1>Sign Up</h1>
			First Name: <br>
			<input type="text" class="fname l" name="Fname" placeholder="First Name" required/>
			<br><br>Last Name:<br>
			<input type="text" class="lname l" name="Lname" placeholder="Last Name" required/>
			<br><br>Age:<br>
			<input type="text" class="age l" name="Age"placeholder="Age" required/>

			<br><br>Gender:<br>
			<input type="radio" class="male " name="Gender" value="Male" required>Male
			<input type="radio" class="female" name="Gender" value="Female" required>Female

			<br><br>EMAIL:<br>
			<input type="text" class="user l" name="Uname" placeholder="@chikatweet.com"/> <p>@chikatweet.com</p>
			<br><br>Password:<br>
			<input type="Password" class="pass l" name="Pass" placeholder="Password" required/>
			<br><br>Retype Password:<br>
			<input type="Password" class="Rpass l" name="RPass" placeholder="Retype Password" required/>
			<br><br>
			<input type="submit"  value="	Confirm        " class="">
			</form>
			
			
	
	</div>
	
	<div class="loginboxxs">
           <h1>ChikkaTweets</h1>
 <img class="mySlides" src="image/chikka.png" style="width:100%" height="300">
  <img class="mySlides" src="image/3.jpg" style="width:100%" height="300">
  <img class="mySlides" src="image/meme.png" style="width:100%" height="300">

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); // Change image every 2 seconds
}
</script>

		   
	</div>
	
	
</body>

</html>