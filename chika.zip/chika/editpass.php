<?php
session_start();
include 'dbs.php';

if(isset($_SESSION['id']))
	{
	$id = $_SESSION['id'];
	$opass = $_POST['OPass'];
	$Password = $_POST['Pass'];
	$RPassword = $_POST['RPass'];
			

	$sql = "SELECT * FROM login WHERE ID = '$id'" ; 
	$result = $conn->query($sql);

	If(!$row = $result->fetch_assoc())
	{
	header("location: index.php");
	echo "Your username/Password is incorrect!";
	}
	else 
	{
		$dpass = $row['Password'];
		
		if($dpass = $opass)
		{

			if ($Password = $RPassword) 
			{
				$sql = "UPDATE login SET Password = '$Password' WHERE ID = '$id'";
				$result = $conn->query($sql);
				session_destroy();
				header("location: index.php");
			}
		}
		else
		{
			echo "wrong pass";
		}
	}
}
else
{
echo "not logged in";
}




	