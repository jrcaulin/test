<?php
include 'dbs.php';
if (isset($_POST['btn-delete'])) {
	$pid = $_POST['pid'];

	$sql = "DELETE FROM posts WHERE ID = '$pid'";
	$result = $conn->query($sql);
	header("Location: home.php");
}